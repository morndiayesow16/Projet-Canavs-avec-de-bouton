
        var cnvas = document.getElementById("mor");
        var ctx = cnvas.getContext("2d");

        cnvas.width= window.innerWidth;
        cnvas.height = window.innerHeight;

        ctx.fillStyle = "#92B901";
        ctx.fillRect(600, 30, 100, 100);
        var w=100;
        function haute(){
                w=w+2;          
                ctx.fillRect(600, 30, 100, w);
        }
        function chgcolor(){
                ctx.fillStyle = "#000ff7";
                ctx.fillRect(600, 30, 100, w);
        }

        function colorinit(){
                ctx.fillStyle = "#92B901";
                ctx.fillRect(600, 30, 100, w);
        }

        function dispa(){
                ctx.clearRect(0, 0, cnvas.width, cnvas.height);
        }

        function reappa(){
                ctx.fillRect(600, 30, 100, w);
        }
